

<?php $__env->startSection('title', 'Auditoría de Actividades'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <div class="dashboard-header">
        <div class="header-content">
            <h1>Historial de Actividades</h1>
            <p>Registro de seguridad de todas las acciones realizadas en el sistema.</p>
        </div>
    </div>

    <div class="content-card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Acción</th>
                            <th>Módulo</th>
                            <th>Descripción</th>
                            <th>Fecha y Hora</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div style="display:flex; align-items:center; gap:10px;">
                                        <div style="width:30px; height:30px; background:var(--primary-color); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-size:0.8rem;">
                                            <?php echo e(substr($log->user->name, 0, 1)); ?>

                                        </div>
                                        <div>
                                            <strong><?php echo e($log->user->name); ?></strong><br>
                                            <small style="color:#999;"><?php echo e($log->user->role); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php
                                        $color = 'gray';
                                        if($log->accion == 'Crear') $color = 'green';
                                        if($log->accion == 'Actualizar') $color = 'orange';
                                        if($log->accion == 'Eliminar') $color = 'red';
                                    ?>
                                    <span class="badge" style="background: <?php echo e($color); ?>; color: white;"><?php echo e($log->accion); ?></span>
                                </td>
                                <td><?php echo e($log->modulo); ?></td>
                                <td><?php echo e($log->descripcion); ?></td>
                                <td><?php echo e($log->created_at->format('d/m/Y H:i:s')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center">No hay actividad registrada aún.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination-container"><?php echo e($logs->links()); ?></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\renzo.DESKTOP-6OKHU0H\Downloads\Wasiqhari (1) (1)\Wasiqhari\resources\views/dashboard/auditoria.blade.php ENDPATH**/ ?>