<?php $__empty_1 = true; $__currentLoopData = $adultos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adulto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr id="fila-adulto-<?php echo e($adulto->id); ?>">
        <td><?php echo e($adulto->nombres); ?> <?php echo e($adulto->apellidos); ?></td>
        <td><?php echo e($adulto->dni ?? 'N/A'); ?></td>
        <td><?php echo e($adulto->distrito); ?></td>
        <td>
            <span class="badge badge-<?php echo e(strtolower($adulto->estado_salud)); ?>">
                <?php echo e($adulto->estado_salud); ?>

            </span>
        </td>
        <td>
            <span class="badge badge-riesgo-<?php echo e(strtolower($adulto->nivel_riesgo)); ?>">
                <?php echo e($adulto->nivel_riesgo); ?>

            </span>
        </td>
        <td><?php echo e($adulto->fecha_registro->format('d/m/Y')); ?></td>
        <td>
            <?php if($adulto->telefono): ?>
                <a href="https://wa.me/51<?php echo e(preg_replace('/[^0-9]/', '', $adulto->telefono)); ?>?text=Hola <?php echo e($adulto->nombres); ?>, le escribo de WasiQhari." 
                   target="_blank" class="btn-action btn-whatsapp" title="Chat">
                    <i class="fab fa-whatsapp"></i>
                </a>
            <?php endif; ?>

            <a href="<?php echo e(route('adultos.credencial', $adulto->id)); ?>" target="_blank" class="btn-action btn-credencial" title="Credencial">
                <i class="fas fa-id-card"></i>
            </a>
            
            <a href="<?php echo e(route('adultos.evolucion', $adulto->id)); ?>" class="btn-action" style="color: #3498db;" title="Ver Evolución">
                <i class="fas fa-chart-line"></i>
            </a>

            <button class="btn-action btn-ver" data-id="<?php echo e($adulto->id); ?>" title="Editar">
                <i class="fas fa-eye"></i>
            </button>
            
            <button class="btn-action btn-eliminar" data-id="<?php echo e($adulto->id); ?>" data-name="<?php echo e($adulto->nombres); ?>" title="Eliminar">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="7" class="text-center" style="padding: 20px; color: #999;">
            No hay adultos mayores registrados.
        </td>
    </tr>
<?php endif; ?>

<tr style="display:none;"><td colspan="7"><div id="pagination-links-hidden"><?php echo e($adultos->links()); ?></div></td></tr><?php /**PATH C:\Users\renzo.DESKTOP-6OKHU0H\Downloads\Wasiqhari (1) (1)\Wasiqhari\resources\views/dashboard/partials/tabla_adultos.blade.php ENDPATH**/ ?>